# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 23:38:29 2024

@author: KILLGOD
"""


import flet as ft




import flet
from flet import (
    Column,
    ElevatedButton,
    FilePicker,
    FilePickerResultEvent,
    ProgressRing,
    Ref,
    Row,
    Text,
    icons,
)






def main(page: ft.Page):
    
    page.title = "WEBFORM GENERATOR"
    #page.icon = "assets/images/ncr_icon.ico"

        
            
           
                
        
    
    def btn_click(e):
        pass
    
    
               
    def delete_click(e: ft.ContainerTapEvent):
        pass
    
     
   

    files = Ref[Column]()
    enviar_mail = Ref[ElevatedButton]()


    def file_picker_result(e: FilePickerResultEvent):
        pass
       

    

    file_picker = FilePicker(on_result=file_picker_result)
    page.overlay.append(file_picker)

   
    
     
    title = ft.Text("WEBFORM GENERATOR:") 
    correo_to = ft.TextField(label="Mail to:", multiline=True, min_lines=1,max_lines=2,autofocus=True,) 
    
    emision = ft.TextField(label="Fecha Emison:", value = "01/01/01")
    
    f_visita = ft.TextField(label="Fecha Visita:", value = "15:35")
    
    Code_CE = ft.TextField(label="Legajo")
    
    work_order = ft.TextField(label="Workorder",  keyboard_type = "NUMBER",
                              input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]", replacement_string=""))
    
    
    customer = ft.TextField(label="Cliente:", multiline=True, min_lines=1,max_lines=2) 
    
    modelo = ft.TextField(label="Modelo:")
    
    serial = ft.TextField(label="Serial:")
    
    comentario = ft.TextField(label="Remark", multiline=True, min_lines=1,max_lines=5) 
    
      

    
    
    cl = ft.Column(
        #spacing=10,
        height=page.height,
        #width=600,
        scroll=ft.ScrollMode.ALWAYS
        
    
    )
    
    
    
    IMAGE_LOGO = ft.Container(
         #width=400,
         #height=400,
         #bgcolor=ft.colors.CYAN_200,
         border_radius=5,
         content=ft.Image(
         src="assets/images/ncr_atleos.png",
         width=350,
         #height=350,
         fit=ft.ImageFit.SCALE_DOWN,
         #repeat=ft.ImageRepeat.NO_REPEAT,
         border_radius=ft.border_radius.all(10),
         
     ),alignment=ft.alignment.center,
        
        )
    
    cl.controls.append(IMAGE_LOGO)
    
    
    cl.controls.append(ft.Container(content = title))
    cl.controls.append(ft.Container(content = correo_to))
    
    cl.controls.append(ft.Container(content = emision))
    
    cl.controls.append(ft.Container(content = f_visita))
    
    cl.controls.append(ft.Container(content = Code_CE))
    
    cl.controls.append(ft.Container(content = work_order))
    
    cl.controls.append(ft.Container(content = customer))
    
    cl.controls.append(ft.Container(content = modelo))
    
    cl.controls.append(ft.Container(content = serial))
    
    cl.controls.append(ft.Container(content = comentario))
    
   
    
    
    cl4 = ft.Container(content = ElevatedButton(
        "Select files...",
        icon=icons.FOLDER_OPEN,
        on_click=lambda _: file_picker.pick_files(allow_multiple=True),
    ))
    
    
    cl.controls.append(cl4)
    
    cl.controls.append(ft.Container(content = Column(ref=files) ) )
    
    images = ft.GridView(expand=1, runs_count=3, run_spacing=2)
    
    
    cl.controls.append(ft.Container(content = images))
    
    cl_enviar =  ft.Container(content = ft.ElevatedButton(
         "Enviar",
         ref=enviar_mail,
         icon=icons.EMAIL,
         on_click=btn_click,
         disabled=True
     ),
        alignment=ft.alignment.center
        
        
        )
    
    cl.controls.append(cl_enviar)

    
    
    
 
    
    page.add(cl)
    
    


ft.app(target=main,  assets_dir="assets", upload_dir="assets/uploads" ) #, view=ft.AppView.WEB_BROWSER)